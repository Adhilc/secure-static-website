import json
import boto3

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket_name = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']
        print(f"File {object_key} uploaded to bucket {bucket_name}.")
        
        # Set public-read permissions
        try:
            s3_client.put_object_acl(
                ACL='public-read',
                Bucket=bucket_name,
                Key=object_key
            )
            print(f"Permissions for {object_key} updated to public-read.")
        except Exception as e:
            print(f"Error setting ACL: {e}")
    return {
        'statusCode': 200,
        'body': json.dumps('File processed successfully!')
    }
